﻿Tripo Public Usage Manager v2.0.14 - Final Integrated Installer

처음 설치할 때는 아래 순서대로 진행하세요.

1. 이 ZIP 파일의 압축을 전용 폴더에 풉니다.
   권장 위치:
   C:\TripoPublicManager
   또는
   D:\TripoPublicManager

2. Chrome 주소창에 아래 주소를 입력합니다.
   chrome://extensions

3. 오른쪽 위의 '개발자 모드'를 켭니다.

4. '압축해제된 확장 프로그램을 로드합니다'를 누릅니다.

5. 이 설치판 안의 'extension' 폴더를 선택합니다.

6. 'windows-helper' 폴더를 엽니다.

7. 아래 파일을 더블클릭합니다.
   1_INSTALL_TRIPO.cmd

8. 설치 완료 창이 나오면 Chrome을 완전히 종료했다가 다시 실행합니다.

처음 설치할 때 실제로 실행할 파일은:
1_INSTALL_TRIPO.cmd

나중에 업데이트 도우미를 직접 열어야 할 때만:
2_RUN_UPDATE_HELPER.cmd

고급 수동 설치가 필요할 때만:
3_INSTALL_NATIVE_HOST_ADVANCED.cmd

일반 사용자는 3번 파일을 실행할 필요가 없습니다.

이후 업데이트 방법:
1. Tripo 화면에서 '업데이트하기' 클릭
2. 최신 ZIP 자동 다운로드
3. Tripo 관리 파일만 백업 및 교체
4. 사용자 개인 파일 유지
5. Chrome 확장 프로그램 관리 화면 열기

이미 최신 버전이면 업데이트 도우미는 안내 후 자동으로 닫힙니다.
