﻿@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-NativeHost-Easy.ps1"
if errorlevel 1 (
  echo.
  echo Installation did not complete. Check the message box and diagnostic log.
  pause
)
endlocal
