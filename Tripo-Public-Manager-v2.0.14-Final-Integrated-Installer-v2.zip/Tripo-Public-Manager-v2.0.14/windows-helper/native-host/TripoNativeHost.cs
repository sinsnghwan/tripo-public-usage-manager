﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Web.Script.Serialization;

internal static class TripoNativeHost
{
    private const int MaxInputBytes = 1024 * 1024;
    private static readonly JavaScriptSerializer Json = new JavaScriptSerializer();

    private static int Main(string[] args)
    {
        try
        {
            Dictionary<string, object> request = ReadMessage();
            Dictionary<string, object> response = Handle(request);
            WriteMessage(response);
            return 0;
        }
        catch (Exception ex)
        {
            TryWriteDiagnostic("fatal", ex.ToString());
            try
            {
                WriteMessage(new Dictionary<string, object>
                {
                    { "ok", false },
                    { "code", "native-host-error" },
                    { "message", ex.Message }
                });
            }
            catch { }
            return 1;
        }
    }

    private static Dictionary<string, object> Handle(Dictionary<string, object> request)
    {
        string action = GetString(request, "action");
        string installRoot = Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, ".."));
        string updaterScript = Path.Combine(installRoot, "Tripo-Update-Helper.ps1");
        string updaterCmd = Path.Combine(installRoot, "2_RUN_UPDATE_HELPER.cmd");
        string updaterShortcut = Path.Combine(installRoot, "Launch-Tripo-Updater.lnk");

        if (action == "ping")
        {
            return Ok("pong", new Dictionary<string, object>
            {
                { "hostVersion", "1.0.2" },
                { "updaterInstalled", File.Exists(updaterShortcut) || File.Exists(updaterScript) || File.Exists(updaterCmd) }
            });
        }

        if (action == "getStatus")
        {
            return Ok("status", new Dictionary<string, object>
            {
                { "hostVersion", "1.0.2" },
                { "installRoot", installRoot },
                { "updaterScript", updaterScript },
                { "updaterCommand", updaterCmd },
                { "updaterInstalled", File.Exists(updaterShortcut) || File.Exists(updaterScript) || File.Exists(updaterCmd) }
            });
        }

        if (action == "launchUpdater")
        {
            Process process = LaunchUpdater(installRoot, updaterShortcut, updaterScript, updaterCmd);
            TryWriteDiagnostic("launch-success", "pid=" + process.Id + ", root=" + installRoot);

            return Ok("updater-launched", new Dictionary<string, object>
            {
                { "hostVersion", "1.0.2" },
                { "processId", process.Id },
                { "requestedVersion", GetString(request, "requestedVersion") },
                { "launchMethod", File.Exists(updaterShortcut) ? "explorer-shortcut" : (File.Exists(updaterScript) ? "powershell-script" : "cmd-fallback") }
            });
        }

        return new Dictionary<string, object>
        {
            { "ok", false },
            { "code", "unknown-action" },
            { "message", "지원하지 않는 요청입니다: " + action }
        };
    }

    private static Process LaunchUpdater(string installRoot, string updaterShortcut, string updaterScript, string updaterCmd)
    {
        // Native Messaging hosts may be placed in a Chromium job object.
        // A direct child process can disappear when the one-shot host exits.
        // Ask the already-running Windows Explorer shell to open a shortcut so
        // the updater is launched independently from the native host lifetime.
        if (File.Exists(updaterShortcut))
        {
            ProcessStartInfo explorerInfo = new ProcessStartInfo
            {
                FileName = "explorer.exe",
                Arguments = "\"" + updaterShortcut + "\"",
                WorkingDirectory = installRoot,
                UseShellExecute = false,
                CreateNoWindow = true
            };

            Process explorer = Process.Start(explorerInfo);
            if (explorer == null)
                throw new InvalidOperationException("Windows 탐색기를 통한 업데이트 도우미 실행에 실패했습니다.");
            return explorer;
        }

        if (File.Exists(updaterScript))
        {
            ProcessStartInfo startInfo = new ProcessStartInfo
            {
                FileName = "powershell.exe",
                Arguments = "-NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Normal -File \"" + updaterScript + "\"",
                WorkingDirectory = installRoot,
                UseShellExecute = true,
                WindowStyle = ProcessWindowStyle.Normal
            };

            Process started = Process.Start(startInfo);
            if (started == null)
                throw new InvalidOperationException("PowerShell 업데이트 도우미 프로세스를 시작하지 못했습니다.");
            return started;
        }

        if (File.Exists(updaterCmd))
        {
            ProcessStartInfo fallbackInfo = new ProcessStartInfo
            {
                FileName = "cmd.exe",
                Arguments = "/d /c start \"\" \"" + updaterCmd + "\"",
                WorkingDirectory = installRoot,
                UseShellExecute = false,
                CreateNoWindow = true
            };

            Process fallback = Process.Start(fallbackInfo);
            if (fallback == null)
                throw new InvalidOperationException("CMD 업데이트 도우미 프로세스를 시작하지 못했습니다.");
            return fallback;
        }

        throw new FileNotFoundException(
            "Tripo 업데이트 도우미 실행 파일을 찾지 못했습니다.",
            updaterShortcut
        );
    }

    private static void TryWriteDiagnostic(string eventName, string detail)
    {
        try
        {
            string installRoot = Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, ".."));
            string logPath = Path.Combine(installRoot, "native-host-launch.log");
            File.AppendAllText(
                logPath,
                DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " [" + eventName + "] " + detail + Environment.NewLine,
                Encoding.UTF8
            );
        }
        catch { }
    }

    private static Dictionary<string, object> Ok(string code, Dictionary<string, object> extra)
    {
        var result = new Dictionary<string, object>
        {
            { "ok", true },
            { "code", code }
        };
        foreach (var item in extra) result[item.Key] = item.Value;
        return result;
    }

    private static string GetString(Dictionary<string, object> source, string key)
    {
        object value;
        return source != null && source.TryGetValue(key, out value) && value != null
            ? Convert.ToString(value)
            : string.Empty;
    }

    private static Dictionary<string, object> ReadMessage()
    {
        Stream input = Console.OpenStandardInput();
        byte[] lengthBytes = ReadExactly(input, 4);
        int length = BitConverter.ToInt32(lengthBytes, 0);
        if (length < 0 || length > MaxInputBytes)
            throw new InvalidDataException("Native Messaging 입력 크기가 올바르지 않습니다.");

        byte[] payload = ReadExactly(input, length);
        string json = Encoding.UTF8.GetString(payload);
        return Json.Deserialize<Dictionary<string, object>>(json)
            ?? new Dictionary<string, object>();
    }

    private static void WriteMessage(Dictionary<string, object> message)
    {
        byte[] payload = Encoding.UTF8.GetBytes(Json.Serialize(message));
        byte[] length = BitConverter.GetBytes(payload.Length);
        Stream output = Console.OpenStandardOutput();
        output.Write(length, 0, length.Length);
        output.Write(payload, 0, payload.Length);
        output.Flush();
    }

    private static byte[] ReadExactly(Stream stream, int count)
    {
        byte[] buffer = new byte[count];
        int offset = 0;
        while (offset < count)
        {
            int read = stream.Read(buffer, offset, count - offset);
            if (read <= 0) throw new EndOfStreamException("Native Messaging 입력이 중간에 종료되었습니다.");
            offset += read;
        }
        return buffer;
    }
}
