﻿Tripo Update Helper

실행 순서

1. 처음 설치:
   1_INSTALL_TRIPO.cmd

2. 업데이트 도우미를 직접 실행해야 할 때:
   2_RUN_UPDATE_HELPER.cmd

3. 고급 수동 Native Host 설치:
   3_INSTALL_NATIVE_HOST_ADVANCED.cmd

일반 사용자는 1_INSTALL_TRIPO.cmd만 실행하면 됩니다.
