﻿Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName Microsoft.VisualBasic
[System.Windows.Forms.Application]::EnableVisualStyles()
$ErrorActionPreference = "Stop"

$HostName = "com.sinsnghwan.tripo_update_helper"
$InstallRoot = Join-Path $env:LOCALAPPDATA "TripoPublicManagerUpdater"
$NativeRoot = Join-Path $InstallRoot "native-host"
$SourceRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$SourceNativeRoot = Join-Path $SourceRoot "native-host"
$SourceCode = Join-Path $SourceNativeRoot "TripoNativeHost.cs"
$HostExe = Join-Path $NativeRoot "TripoNativeHost.exe"
$HostManifest = Join-Path $NativeRoot "$HostName.json"

function Show-Error([string]$Message) {
    [System.Windows.Forms.MessageBox]::Show($Message,"Native Host 설치 실패","OK","Error") | Out-Null
}

function Normalize-ExtensionIds([string]$Raw) {
    $ids = @($Raw -split '[,;\s]+' | ForEach-Object { $_.Trim().ToLowerInvariant() } | Where-Object { $_ })
    if ($ids.Count -eq 0) { throw "확장 프로그램 ID를 한 개 이상 입력해야 합니다." }
    foreach ($id in $ids) {
        if ($id -notmatch '^[a-p]{32}$') {
            throw "확장 프로그램 ID 형식이 올바르지 않습니다: $id`r`n영문 a~p 32자리여야 합니다."
        }
    }
    return @($ids | Select-Object -Unique)
}

try {
    $guide = @"
Chrome 또는 Whale의 확장 프로그램 관리 화면에서
Tripo 확장 프로그램 카드에 표시된 ID를 복사하세요.

- Chrome: chrome://extensions
- Whale: whale://extensions
- 개발자 모드를 켜야 ID가 보일 수 있습니다.
- 두 브라우저를 모두 쓰면 ID를 쉼표로 구분해 입력하세요.
"@
    [System.Windows.Forms.MessageBox]::Show($guide,"설치 전 확인","OK","Information") | Out-Null

    $rawIds = [Microsoft.VisualBasic.Interaction]::InputBox(
        "Tripo 확장 프로그램 ID를 입력하세요.`r`n여러 개면 쉼표로 구분하세요.",
        "Native Host 등록",
        ""
    )
    if ([string]::IsNullOrWhiteSpace($rawIds)) { return }
    $extensionIds = Normalize-ExtensionIds $rawIds

    New-Item -ItemType Directory -Force -Path $InstallRoot,$NativeRoot | Out-Null

    Copy-Item -LiteralPath (Join-Path $SourceRoot "Tripo-Update-Helper.ps1") -Destination $InstallRoot -Force
    Copy-Item -LiteralPath (Join-Path $SourceRoot "2_RUN_UPDATE_HELPER.cmd") -Destination $InstallRoot -Force
    Copy-Item -LiteralPath $SourceCode -Destination $NativeRoot -Force

    $compiler = Join-Path ([Runtime.InteropServices.RuntimeEnvironment]::GetRuntimeDirectory()) "csc.exe"
    if (-not (Test-Path $compiler)) { throw ".NET Framework C# 컴파일러(csc.exe)를 찾지 못했습니다." }

    $compile = Start-Process -FilePath $compiler -ArgumentList @(
        "/nologo",
        "/target:exe",
        "/platform:anycpu",
        "/reference:System.Web.Extensions.dll",
        "/out:`"$HostExe`"",
        "`"$SourceCode`""
    ) -Wait -PassThru -NoNewWindow
    if ($compile.ExitCode -ne 0 -or -not (Test-Path $HostExe)) {
        throw "Native Host 실행 파일 생성에 실패했습니다."
    }

    $manifestObject = [ordered]@{
        name = $HostName
        description = "Tripo 업데이트 도우미 Native Messaging Host"
        path = $HostExe
        type = "stdio"
        allowed_origins = @($extensionIds | ForEach-Object { "chrome-extension://$_/" })
    }
    $manifestObject | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $HostManifest -Encoding UTF8

    $registryPaths = @(
        "HKCU:\Software\Google\Chrome\NativeMessagingHosts\$HostName",
        "HKCU:\Software\Naver\Naver Whale\NativeMessagingHosts\$HostName"
    )
    foreach ($registryPath in $registryPaths) {
        New-Item -Path $registryPath -Force | Out-Null
        Set-Item -Path $registryPath -Value $HostManifest
    }

    $saved = [ordered]@{
        installedAt = (Get-Date).ToString("o")
        hostName = $HostName
        extensionIds = $extensionIds
        hostManifest = $HostManifest
        registryPaths = $registryPaths
    }
    $saved | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $InstallRoot "native-host-install.json") -Encoding UTF8

    [System.Windows.Forms.MessageBox]::Show(
        "Native Host 설치가 완료되었습니다.`r`n`r`nChrome/Whale을 완전히 종료했다가 다시 실행한 뒤 연결 시험을 진행하세요.`r`n`r`n설치 위치:`r`n$InstallRoot",
        "설치 완료","OK","Information"
    ) | Out-Null
}
catch {
    Show-Error $_.Exception.Message
    exit 1
}
