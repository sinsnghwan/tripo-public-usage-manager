﻿Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.IO.Compression.FileSystem
[System.Windows.Forms.Application]::EnableVisualStyles()
$ErrorActionPreference = "Stop"

$AppKey = "tripo-public-manager"
$SupabaseUrl = "https://pacxelpgvhiykoptknfx.supabase.co"
$SupabaseAnonKey = "sb_publishable_z5zP1C4-nrcMTkbUXtzjPg_g4xkJGwY"
$GitHubRawBase = "https://raw.githubusercontent.com/sinsnghwan/tripo-public-usage-manager/main"
$ConfigRoot = Join-Path $env:LOCALAPPDATA "TripoPublicManagerUpdater"
$ConfigPath = Join-Path $ConfigRoot "config.json"
$BackupRoot = Join-Path $ConfigRoot "backups"
$ManagedListName = ".tripo-managed-files.json"
New-Item -ItemType Directory -Force -Path $ConfigRoot,$BackupRoot | Out-Null

function Read-Config {
    if (Test-Path $ConfigPath) {
        try { return Get-Content -Raw -Encoding UTF8 $ConfigPath | ConvertFrom-Json } catch {}
    }
    return [pscustomobject]@{ extensionPath = ""; browsers = @() }
}

function Save-Config([string]$Path) {
    $existingBrowsers = @()
    if (Test-Path $ConfigPath) {
        try {
            $existing = Get-Content -Raw -Encoding UTF8 $ConfigPath | ConvertFrom-Json
            $existingBrowsers = @($existing.browsers)
        } catch {}
    }
    [pscustomobject]@{
        extensionPath = $Path
        browsers = @($existingBrowsers)
        savedAt = (Get-Date).ToString("o")
    } | ConvertTo-Json -Depth 4 | Set-Content -Encoding UTF8 $ConfigPath
}

function Get-Manifest([string]$Path) {
    if ([string]::IsNullOrWhiteSpace($Path)) { throw "확장 프로그램 폴더를 먼저 선택하세요." }
    $manifest = Join-Path $Path "manifest.json"
    if (-not (Test-Path $manifest)) {
        throw "manifest.json이 있는 확장 프로그램 최상위 폴더를 선택하세요."
    }
    return Get-Content -Raw -Encoding UTF8 $manifest | ConvertFrom-Json
}

function Get-LatestInfo {
    $uri = "$SupabaseUrl/rest/v1/tripo_app_versions?select=latest_version,update_message,required,updated_at&app_key=eq.$AppKey&limit=1"
    $headers = @{ apikey=$SupabaseAnonKey; Authorization="Bearer $SupabaseAnonKey"; Accept="application/json" }
    $rows = Invoke-RestMethod -Method Get -Uri $uri -Headers $headers -TimeoutSec 20
    if (-not $rows -or $rows.Count -eq 0) { throw "최신 버전 정보를 찾지 못했습니다." }
    return $rows[0]
}

function Find-ExtensionRoot([string]$ExtractRoot) {
    if (Test-Path (Join-Path $ExtractRoot "manifest.json")) { return $ExtractRoot }
    $items = @(Get-ChildItem -Path $ExtractRoot -Filter manifest.json -File -Recurse)
    if ($items.Count -eq 1) { return $items[0].Directory.FullName }
    if ($items.Count -eq 0) { throw "ZIP에서 manifest.json을 찾지 못했습니다." }
    throw "ZIP 안에 확장 프로그램 폴더가 여러 개 있습니다."
}

function Normalize-RelativePath([string]$RelativePath) {
    if ([string]::IsNullOrWhiteSpace($RelativePath)) { throw "비어 있는 관리 파일 경로가 있습니다." }
    $value = $RelativePath.Replace("\", "/").TrimStart("/")
    if ($value -match '(^|/)\.\.(/|$)') { throw "상위 폴더 이동 경로는 허용되지 않습니다: $RelativePath" }
    if ([System.IO.Path]::IsPathRooted($value)) { throw "절대 경로는 허용되지 않습니다: $RelativePath" }
    return $value
}

function Get-ManagedFilesFromPackage([string]$Root) {
    $markerPath = Join-Path $Root $ManagedListName
    if (Test-Path $markerPath) {
        $marker = Get-Content -Raw -Encoding UTF8 $markerPath | ConvertFrom-Json
        $items = @($marker.managedFiles)
    }
    else {
        $items = @(Get-ChildItem -LiteralPath $Root -File -Recurse -Force | ForEach-Object {
            $_.FullName.Substring($Root.Length).TrimStart('\','/').Replace('\','/')
        })
    }

    $result = New-Object System.Collections.Generic.List[string]
    foreach ($item in $items) {
        $relative = Normalize-RelativePath ([string]$item)
        if ($relative -eq $ManagedListName) { continue }
        $source = Join-Path $Root ($relative.Replace('/', [System.IO.Path]::DirectorySeparatorChar))
        if (-not (Test-Path -LiteralPath $source -PathType Leaf)) {
            throw "관리 파일 목록에 있지만 ZIP에서 찾을 수 없습니다: $relative"
        }
        if (-not $result.Contains($relative)) { $result.Add($relative) }
    }
    return @($result)
}

function Get-PreviousManagedFiles([string]$Root) {
    $markerPath = Join-Path $Root $ManagedListName
    if (-not (Test-Path $markerPath)) { return @() }
    try {
        $marker = Get-Content -Raw -Encoding UTF8 $markerPath | ConvertFrom-Json
        $result = @()
        foreach ($item in @($marker.managedFiles)) {
            $relative = Normalize-RelativePath ([string]$item)
            if ($relative -ne $ManagedListName) { $result += $relative }
        }
        return @($result | Select-Object -Unique)
    }
    catch {
        throw "기존 관리 파일 목록을 읽지 못했습니다. 안전을 위해 업데이트를 중단합니다.`r`n$($_.Exception.Message)"
    }
}

function Get-FullManagedPath([string]$Root,[string]$RelativePath) {
    $relative = Normalize-RelativePath $RelativePath
    $fullRoot = [System.IO.Path]::GetFullPath($Root).TrimEnd('\','/') + [System.IO.Path]::DirectorySeparatorChar
    $fullPath = [System.IO.Path]::GetFullPath((Join-Path $Root ($relative.Replace('/', [System.IO.Path]::DirectorySeparatorChar))))
    if (-not $fullPath.StartsWith($fullRoot, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "설치 폴더 밖의 경로는 처리할 수 없습니다: $RelativePath"
    }
    return $fullPath
}

function Backup-ManagedFiles([string]$Root,[string[]]$RelativePaths,[string]$BackupPath) {
    New-Item -ItemType Directory -Force -Path $BackupPath | Out-Null
    $existing = New-Object System.Collections.Generic.List[string]
    foreach ($relative in @($RelativePaths | Select-Object -Unique)) {
        $source = Get-FullManagedPath $Root $relative
        if (Test-Path -LiteralPath $source -PathType Leaf) {
            $destination = Get-FullManagedPath $BackupPath $relative
            New-Item -ItemType Directory -Force -Path (Split-Path $destination -Parent) | Out-Null
            Copy-Item -LiteralPath $source -Destination $destination -Force
            $existing.Add($relative)
        }
    }
    $marker = Join-Path $Root $ManagedListName
    if (Test-Path $marker -PathType Leaf) {
        Copy-Item -LiteralPath $marker -Destination (Join-Path $BackupPath $ManagedListName) -Force
    }
    [pscustomobject]@{ existingFiles=@($existing) } | ConvertTo-Json -Depth 4 |
        Set-Content -Encoding UTF8 (Join-Path $BackupPath 'backup-state.json')
}

function Remove-ManagedFiles([string]$Root,[string[]]$RelativePaths) {
    foreach ($relative in @($RelativePaths | Select-Object -Unique)) {
        $path = Get-FullManagedPath $Root $relative
        if (Test-Path -LiteralPath $path -PathType Leaf) {
            Remove-Item -LiteralPath $path -Force
        }
    }
}

function Copy-ManagedFiles([string]$From,[string]$To,[string[]]$RelativePaths) {
    foreach ($relative in @($RelativePaths | Select-Object -Unique)) {
        $source = Get-FullManagedPath $From $relative
        $destination = Get-FullManagedPath $To $relative
        New-Item -ItemType Directory -Force -Path (Split-Path $destination -Parent) | Out-Null
        Copy-Item -LiteralPath $source -Destination $destination -Force
    }
}

function Write-ManagedMarker([string]$Root,[string[]]$RelativePaths) {
    $markerPath = Join-Path $Root $ManagedListName
    [pscustomobject]@{
        schemaVersion = 1
        managedFiles = @($RelativePaths | Select-Object -Unique)
        updatedAt = (Get-Date).ToString('o')
    } | ConvertTo-Json -Depth 5 | Set-Content -Encoding UTF8 $markerPath
}

function Restore-ManagedBackup([string]$Root,[string]$BackupPath,[string[]]$NewManagedFiles) {
    Remove-ManagedFiles $Root $NewManagedFiles
    $statePath = Join-Path $BackupPath 'backup-state.json'
    if (Test-Path $statePath) {
        $state = Get-Content -Raw -Encoding UTF8 $statePath | ConvertFrom-Json
        Copy-ManagedFiles $BackupPath $Root @($state.existingFiles)
    }
    $backupMarker = Join-Path $BackupPath $ManagedListName
    $targetMarker = Join-Path $Root $ManagedListName
    if (Test-Path $backupMarker) {
        Copy-Item -LiteralPath $backupMarker -Destination $targetMarker -Force
    }
    elseif (Test-Path $targetMarker) {
        Remove-Item -LiteralPath $targetMarker -Force
    }
}

function Get-BrowserExecutable([string]$Browser) {
    $candidates = @()

    if ($Browser -eq 'Chrome') {
        $appPathKeys = @(
            'Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe',
            'Registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe',
            'Registry::HKEY_LOCAL_MACHINE\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe'
        )
        $candidates += @(
            (Join-Path $env:ProgramFiles 'Google\Chrome\Application\chrome.exe'),
            (Join-Path ${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe'),
            (Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe')
        )
        $fallbackName = 'chrome.exe'
    }
    else {
        $appPathKeys = @(
            'Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\App Paths\whale.exe',
            'Registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\App Paths\whale.exe',
            'Registry::HKEY_LOCAL_MACHINE\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\whale.exe'
        )
        $candidates += @(
            (Join-Path $env:ProgramFiles 'Naver\Naver Whale\Application\whale.exe'),
            (Join-Path ${env:ProgramFiles(x86)} 'Naver\Naver Whale\Application\whale.exe'),
            (Join-Path $env:LOCALAPPDATA 'Naver\Naver Whale\Application\whale.exe')
        )
        $fallbackName = 'whale.exe'
    }

    foreach ($key in $appPathKeys) {
        try {
            $value = (Get-Item -LiteralPath $key -ErrorAction Stop).GetValue('')
            if ($value -and (Test-Path -LiteralPath $value)) {
                return $value
            }
        }
        catch {}
    }

    foreach ($candidate in $candidates) {
        if ($candidate -and (Test-Path -LiteralPath $candidate)) {
            return $candidate
        }
    }

    $command = Get-Command $fallbackName -ErrorAction SilentlyContinue
    if ($command -and $command.Source) {
        return $command.Source
    }

    throw "$Browser 실행 파일을 찾지 못했습니다."
}

function Activate-BrowserAndTypeUrl([string]$Browser,[string]$Url) {
    $exePath = Get-BrowserExecutable $Browser

    # 브라우저 내부 주소는 외부 실행 인자로 전달하면 일반 새 탭으로 무시될 수 있습니다.
    # 따라서 브라우저 창을 연 뒤 주소창에 직접 내부 주소를 입력합니다.
    $process = Start-Process -FilePath $exePath -ArgumentList @('--new-window','about:blank') -PassThru
    Start-Sleep -Milliseconds 1400

    $shell = New-Object -ComObject WScript.Shell
    $activated = $false

    if ($process -and -not $process.HasExited) {
        try { $activated = $shell.AppActivate($process.Id) } catch {}
    }

    if (-not $activated) {
        $titles = if ($Browser -eq 'Chrome') {
            @('Google Chrome','Chrome')
        } else {
            @('NAVER Whale','Whale','네이버 웨일')
        }

        foreach ($title in $titles) {
            try {
                if ($shell.AppActivate($title)) {
                    $activated = $true
                    break
                }
            } catch {}
        }
    }

    if (-not $activated) {
        throw "$Browser 창을 활성화하지 못했습니다."
    }

    Start-Sleep -Milliseconds 350
    $shell.SendKeys('^l')
    Start-Sleep -Milliseconds 150
    $shell.SendKeys($Url)
    Start-Sleep -Milliseconds 150
    $shell.SendKeys('{ENTER}')
    return $true
}

function Open-ExtensionsPage([string]$Browser) {
    $url = if ($Browser -eq 'Chrome') { 'chrome://extensions/' } else { 'whale://extensions/' }

    try {
        return Activate-BrowserAndTypeUrl $Browser $url
    }
    catch {
        try { [System.Windows.Forms.Clipboard]::SetText($url) } catch {}
        [System.Windows.Forms.MessageBox]::Show(
            "$Browser 관리 화면을 자동으로 열지 못했습니다.`r`n`r`n$($_.Exception.Message)`r`n`r`n주소가 클립보드에 복사되었습니다:`r`n$url",
            '관리 화면 열기 실패',
            'OK',
            'Warning'
        ) | Out-Null
        return $false
    }
}

function Open-ConfiguredExtensionPages {
    # 정식 정책: Chrome 관리 화면만 자동으로 엽니다.
    # Whale은 사용자가 직접 whale://extensions 에서 처리합니다.
    return Open-ExtensionsPage 'Chrome'
}

$form = New-Object System.Windows.Forms.Form
$form.Text = "Tripo 업데이트 도우미"
$form.Size = New-Object System.Drawing.Size(760,680)
$form.StartPosition = "CenterScreen"
$form.Font = New-Object System.Drawing.Font("맑은 고딕",10)
$form.BackColor = [System.Drawing.Color]::FromArgb(247,249,252)

$title = New-Object System.Windows.Forms.Label
$title.Text = "Tripo 공용 사용 관리 툴 업데이트"
$title.Font = New-Object System.Drawing.Font("맑은 고딕",17,[System.Drawing.FontStyle]::Bold)
$title.AutoSize = $true
$title.Location = New-Object System.Drawing.Point(24,20)
$form.Controls.Add($title)

$desc = New-Object System.Windows.Forms.Label
$desc.Text = "업데이트 자동 확인 → 관리 파일만 백업·교체 → 완료 후 자동 종료"
$desc.AutoSize = $true
$desc.Location = New-Object System.Drawing.Point(27,60)
$form.Controls.Add($desc)

$pathBox = New-Object System.Windows.Forms.TextBox
$pathBox.Location = New-Object System.Drawing.Point(30,105)
$pathBox.Size = New-Object System.Drawing.Size(575,30)
$pathBox.ReadOnly = $true
$form.Controls.Add($pathBox)

$browse = New-Object System.Windows.Forms.Button
$browse.Text = "폴더 선택"
$browse.Location = New-Object System.Drawing.Point(615,102)
$browse.Size = New-Object System.Drawing.Size(110,34)
$form.Controls.Add($browse)

$current = New-Object System.Windows.Forms.Label
$current.Text = "현재 설치 버전: -"
$current.AutoSize = $true
$current.Location = New-Object System.Drawing.Point(30,160)
$form.Controls.Add($current)

$latest = New-Object System.Windows.Forms.Label
$latest.Text = "최신 배포 버전: 확인 전"
$latest.AutoSize = $true
$latest.Location = New-Object System.Drawing.Point(30,193)
$form.Controls.Add($latest)

$check = New-Object System.Windows.Forms.Button
$check.Text = "최신 버전 확인"
$check.Location = New-Object System.Drawing.Point(560,160)
$check.Size = New-Object System.Drawing.Size(165,40)
$form.Controls.Add($check)

$message = New-Object System.Windows.Forms.TextBox
$message.Location = New-Object System.Drawing.Point(30,230)
$message.Size = New-Object System.Drawing.Size(695,80)
$message.Multiline = $true
$message.ReadOnly = $true
$message.Text = "업데이트 내용을 확인하면 여기에 표시됩니다."
$form.Controls.Add($message)

$update = New-Object System.Windows.Forms.Button
$update.Text = "업데이트 자동 진행 중"
$update.Enabled = $false
$update.Location = New-Object System.Drawing.Point(30,330)
$update.Size = New-Object System.Drawing.Size(695,50)
$update.Font = New-Object System.Drawing.Font("맑은 고딕",11,[System.Drawing.FontStyle]::Bold)
$update.BackColor = [System.Drawing.Color]::FromArgb(43,108,176)
$update.ForeColor = [System.Drawing.Color]::White
$update.FlatStyle = "Flat"
$form.Controls.Add($update)

$progress = New-Object System.Windows.Forms.ProgressBar
$progress.Location = New-Object System.Drawing.Point(30,400)
$progress.Size = New-Object System.Drawing.Size(695,22)
$form.Controls.Add($progress)

$status = New-Object System.Windows.Forms.Label
$status.Text = "대기 중"
$status.AutoSize = $true
$status.Location = New-Object System.Drawing.Point(30,440)
$form.Controls.Add($status)

$guide = New-Object System.Windows.Forms.Label
$guide.Text = "파일 교체 후: Chrome 확장 프로그램 관리 화면만 자동으로 엽니다. Whale은 사용자가 직접 엽니다."
$guide.AutoSize = $false
$guide.Size = New-Object System.Drawing.Size(695,45)
$guide.Location = New-Object System.Drawing.Point(30,485)
$form.Controls.Add($guide)

$chrome = New-Object System.Windows.Forms.Button
$chrome.Text = "Chrome 관리 화면"
$chrome.Location = New-Object System.Drawing.Point(30,540)
$chrome.Size = New-Object System.Drawing.Size(210,38)
$form.Controls.Add($chrome)

$whale = New-Object System.Windows.Forms.Button
$whale.Text = "Whale 관리 화면"
$whale.Location = New-Object System.Drawing.Point(258,540)
$whale.Size = New-Object System.Drawing.Size(210,38)
$form.Controls.Add($whale)

$openFolder = New-Object System.Windows.Forms.Button
$openFolder.Text = "설치 폴더 열기"
$openFolder.Location = New-Object System.Drawing.Point(485,540)
$openFolder.Size = New-Object System.Drawing.Size(210,38)
$form.Controls.Add($openFolder)

$config = Read-Config
if ($config.extensionPath -and (Test-Path $config.extensionPath)) {
    $pathBox.Text = $config.extensionPath
    try { $current.Text = "현재 설치 버전: $((Get-Manifest $pathBox.Text).version)" } catch {}
}

$browse.Add_Click({
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = "manifest.json이 있는 Tripo 확장 프로그램 폴더를 선택하세요."
    if ($dialog.ShowDialog() -eq "OK") {
        try {
            $m = Get-Manifest $dialog.SelectedPath
            $pathBox.Text = $dialog.SelectedPath
            Save-Config $dialog.SelectedPath
            $current.Text = "현재 설치 버전: $($m.version)"
            $status.Text = "폴더가 저장되었습니다."
        } catch {
            [System.Windows.Forms.MessageBox]::Show($_.Exception.Message,"폴더 확인","OK","Warning") | Out-Null
        }
    }
})

$check.Add_Click({
    try {
        $status.Text = "최신 버전 확인 중..."
        $progress.Value = 25
        $info = Get-LatestInfo
        $latest.Text = "최신 배포 버전: $($info.latest_version)"
        $message.Text = [string]$info.update_message
        if ($pathBox.Text) {
            $current.Text = "현재 설치 버전: $((Get-Manifest $pathBox.Text).version)"
        }
        $progress.Value = 100
        $status.Text = "확인 완료"
    } catch {
        $progress.Value = 0
        $status.Text = "확인 실패"
        [System.Windows.Forms.MessageBox]::Show($_.Exception.Message,"오류","OK","Error") | Out-Null
    }
})

$update.Add_Click({
    $temp = $null
    try {
        $oldManifest = Get-Manifest $pathBox.Text
        Save-Config $pathBox.Text
        $info = Get-LatestInfo
        $latestVersion = [string]$info.latest_version
        $latest.Text = "최신 배포 버전: $latestVersion"
        $message.Text = [string]$info.update_message

        $temp = Join-Path $env:TEMP ("TripoUpdater-" + [guid]::NewGuid().ToString("N"))
        $zip = Join-Path $temp "latest.zip"
        $extract = Join-Path $temp "extract"
        New-Item -ItemType Directory -Force -Path $extract | Out-Null

        $progress.Value = 20
        $status.Text = "GitHub에서 최신 ZIP 다운로드 중..."
        $downloadUrl = "$GitHubRawBase/tripo-public-manager-v$latestVersion.zip"
        Invoke-WebRequest -Uri $downloadUrl -OutFile $zip -UseBasicParsing -TimeoutSec 120

        $progress.Value = 40
        $status.Text = "압축 해제 및 파일 확인 중..."
        [System.IO.Compression.ZipFile]::ExtractToDirectory($zip,$extract)
        $newRoot = Find-ExtensionRoot $extract
        $newManifest = Get-Manifest $newRoot
        if ([string]$newManifest.version -ne $latestVersion) {
            throw "다운로드 파일 버전과 최신 버전 정보가 다릅니다."
        }

        $newManagedFiles = Get-ManagedFilesFromPackage $newRoot
        $oldManagedFiles = Get-PreviousManagedFiles $pathBox.Text
        $backupTargets = @($oldManagedFiles + $newManagedFiles | Select-Object -Unique)
        $removedFiles = @($oldManagedFiles | Where-Object { $newManagedFiles -notcontains $_ })

        $backup = Join-Path $BackupRoot ("v$($oldManifest.version)-" + (Get-Date -Format "yyyyMMdd-HHmmss"))
        $progress.Value = 60
        $status.Text = "Tripo 관리 파일만 백업 중..."
        Backup-ManagedFiles $pathBox.Text $backupTargets $backup

        try {
            $progress.Value = 75
            $status.Text = "이전 버전에서 제거된 Tripo 파일 정리 중..."
            Remove-ManagedFiles $pathBox.Text $removedFiles

            $progress.Value = 84
            $status.Text = "새 버전의 Tripo 파일만 교체 중..."
            Copy-ManagedFiles $newRoot $pathBox.Text $newManagedFiles
            Write-ManagedMarker $pathBox.Text $newManagedFiles

            if ([string](Get-Manifest $pathBox.Text).version -ne $latestVersion) {
                throw "교체 후 버전 확인 실패"
            }
        } catch {
            Restore-ManagedBackup $pathBox.Text $backup $newManagedFiles
            throw "파일 교체 실패로 기존 Tripo 파일을 복구했습니다.`r`n$($_.Exception.Message)"
        }

        $progress.Value = 100
        $current.Text = "현재 설치 버전: $latestVersion"
        $status.Text = "업데이트 완료 — Chrome 확장 프로그램 관리 화면을 엽니다."
        [System.Windows.Forms.Application]::DoEvents()
        $opened = Open-ConfiguredExtensionPages
        if ($opened) {
            Start-Sleep -Milliseconds 1200
            $form.Close()
        }
        else {
            $status.Text = "업데이트는 완료됐지만 Chrome 관리 화면을 열지 못했습니다."
        }
    } catch {
        $progress.Value = 0
        $status.Text = "업데이트 실패"
        [System.Windows.Forms.MessageBox]::Show($_.Exception.Message,"업데이트 실패","OK","Error") | Out-Null
    } finally {
        if ($temp -and (Test-Path $temp)) {
            Remove-Item -LiteralPath $temp -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
})

$form.Add_Shown({
    if (-not [string]::IsNullOrWhiteSpace($pathBox.Text)) {
        try {
            $status.Text = "최신 버전 자동 확인 중..."
            $progress.Value = 25
            [System.Windows.Forms.Application]::DoEvents()
            $info = Get-LatestInfo
            $latestVersion = [string]$info.latest_version
            $currentVersion = [string](Get-Manifest $pathBox.Text).version
            $latest.Text = "최신 배포 버전: $latestVersion"
            $message.Text = [string]$info.update_message
            $current.Text = "현재 설치 버전: $currentVersion"

            if ($currentVersion -eq $latestVersion) {
                $progress.Value = 100
                $status.Text = "이미 최신 버전입니다. 2초 후 자동으로 닫힙니다."
        $form.Refresh()
        Start-Sleep -Seconds 2
        $form.Close()
                return
            }

            $progress.Value = 5
            $status.Text = "업데이트를 자동으로 시작합니다..."
            [System.Windows.Forms.Application]::DoEvents()
            $update.Enabled = $true
            $update.PerformClick()
        }
        catch {
            $progress.Value = 0
            $update.Enabled = $true
            $status.Text = "자동 업데이트 실패 — 창을 닫고 다시 시도하세요."
            [System.Windows.Forms.MessageBox]::Show($_.Exception.Message,"자동 업데이트 실패","OK","Error") | Out-Null
        }
    }
})

$chrome.Add_Click({ Open-ExtensionsPage "Chrome" })
$whale.Add_Click({ Open-ExtensionsPage "Whale" })
$openFolder.Add_Click({
    if ($pathBox.Text -and (Test-Path $pathBox.Text)) {
        Start-Process explorer.exe "`"$($pathBox.Text)`""
    }
})

[void]$form.ShowDialog()
