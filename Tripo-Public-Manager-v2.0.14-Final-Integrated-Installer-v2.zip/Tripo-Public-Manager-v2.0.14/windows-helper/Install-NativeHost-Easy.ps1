﻿Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.Application]::EnableVisualStyles()
$ErrorActionPreference = 'Stop'

$HostName = 'com.sinsnghwan.tripo_update_helper'
$InstallRoot = Join-Path $env:LOCALAPPDATA 'TripoPublicManagerUpdater'
$NativeRoot = Join-Path $InstallRoot 'native-host'
$SourceRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$PackageRoot = Split-Path -Parent $SourceRoot
$ExpectedExtensionRoot = Join-Path $PackageRoot 'extension'
$SourceCode = Join-Path $SourceRoot 'native-host\TripoNativeHost.cs'
$HostExe = Join-Path $NativeRoot 'TripoNativeHost.exe'
$HostManifest = Join-Path $NativeRoot ($HostName + '.json')
$LogPath = Join-Path $env:TEMP 'Tripo-NativeHost-AutoInstall.log'
$UpdaterConfigPath = Join-Path $InstallRoot 'config.json'

function Write-Log {
    param([string]$Message)
    $Line = ('[{0}] {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Message)
    Add-Content -LiteralPath $LogPath -Value $Line -Encoding UTF8
}

function Show-Info {
    param([string]$Message, [string]$Title = 'Tripo 간편 설치')
    [System.Windows.Forms.MessageBox]::Show($Message, $Title, 'OK', 'Information') | Out-Null
}

function Show-Warn {
    param([string]$Message, [string]$Title = '확인 필요')
    [System.Windows.Forms.MessageBox]::Show($Message, $Title, 'OK', 'Warning') | Out-Null
}

function Show-ErrorMessage {
    param([string]$Message)
    [System.Windows.Forms.MessageBox]::Show($Message, '설치 실패', 'OK', 'Error') | Out-Null
}

function Get-NormalizedPath {
    param([string]$PathValue, [string]$BasePath = '')
    if ([string]::IsNullOrWhiteSpace($PathValue)) { return '' }
    try {
        $Candidate = [Environment]::ExpandEnvironmentVariables($PathValue.Trim())
        if (-not [System.IO.Path]::IsPathRooted($Candidate) -and -not [string]::IsNullOrWhiteSpace($BasePath)) {
            $Candidate = Join-Path $BasePath $Candidate
        }
        return ([System.IO.Path]::GetFullPath($Candidate)).TrimEnd('\').ToLowerInvariant()
    }
    catch { return '' }
}

function Get-PropertyValue {
    param($Object, [string]$Name)
    if ($null -eq $Object) { return $null }
    $Property = $Object.PSObject.Properties[$Name]
    if ($null -eq $Property) { return $null }
    return $Property.Value
}

function Test-TripoManifest {
    param([string]$ExtensionPath)
    if ([string]::IsNullOrWhiteSpace($ExtensionPath)) { return $false }
    $ManifestPath = Join-Path $ExtensionPath 'manifest.json'
    if (-not (Test-Path -LiteralPath $ManifestPath)) { return $false }
    try {
        $Manifest = Get-Content -LiteralPath $ManifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
        $Name = [string](Get-PropertyValue $Manifest 'name')
        $Description = [string](Get-PropertyValue $Manifest 'description')
        $HasNativePermission = @((Get-PropertyValue $Manifest 'permissions')) -contains 'nativeMessaging'
        return (($Name -like '*Tripo*') -and (($Name -like '*공용*') -or ($Description -like '*공용 계정*')) -and $HasNativePermission)
    }
    catch { return $false }
}

function Get-BrowserProfiles {
    param([string]$BrowserRoot)
    $Profiles = @()
    if (-not (Test-Path -LiteralPath $BrowserRoot)) { return $Profiles }

    $LocalStatePath = Join-Path $BrowserRoot 'Local State'
    if (Test-Path -LiteralPath $LocalStatePath) {
        try {
            $LocalState = Get-Content -LiteralPath $LocalStatePath -Raw -Encoding UTF8 | ConvertFrom-Json
            $Profile = Get-PropertyValue $LocalState 'profile'
            $InfoCache = Get-PropertyValue $Profile 'info_cache'
            if ($null -ne $InfoCache) {
                foreach ($Item in $InfoCache.PSObject.Properties) {
                    $Profiles += $Item.Name
                }
            }
        }
        catch { Write-Log ('Local State parse failed: ' + $LocalStatePath) }
    }

    $Profiles += @('Default')
    $Profiles += @(Get-ChildItem -LiteralPath $BrowserRoot -Directory -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -like 'Profile *' -or $_.Name -eq 'Guest Profile' } |
        ForEach-Object { $_.Name })

    return @($Profiles | Where-Object { $_ } | Select-Object -Unique)
}

function Find-ExtensionInPreference {
    param(
        [string]$PreferenceFile,
        [string]$BrowserName,
        [string]$ProfileName,
        [string]$BrowserRoot,
        [string]$ExpectedPath
    )

    $Results = @()
    if (-not (Test-Path -LiteralPath $PreferenceFile)) { return $Results }

    try {
        $Json = Get-Content -LiteralPath $PreferenceFile -Raw -Encoding UTF8 | ConvertFrom-Json
        $Extensions = Get-PropertyValue $Json 'extensions'
        $Settings = Get-PropertyValue $Extensions 'settings'
        if ($null -eq $Settings) { return $Results }

        foreach ($Entry in $Settings.PSObject.Properties) {
            $Id = [string]$Entry.Name
            if ($Id -notmatch '^[a-p]{32}$') { continue }

            $Value = $Entry.Value
            $RawPath = [string](Get-PropertyValue $Value 'path')
            $ResolvedPath = Get-NormalizedPath $RawPath $BrowserRoot
            $Manifest = Get-PropertyValue $Value 'manifest'
            $StoredName = [string](Get-PropertyValue $Manifest 'name')

            $PathMatches = (-not [string]::IsNullOrWhiteSpace($ResolvedPath)) -and ($ResolvedPath -eq $ExpectedPath)
            $ManifestMatches = Test-TripoManifest $ResolvedPath
            $StoredNameMatches = ($StoredName -like '*Tripo*') -and (($StoredName -like '*공용*') -or ($StoredName -like '*사용 관리*'))

            Write-Log ('Candidate {0}/{1}: id={2}, rawPath={3}, resolvedPath={4}, name={5}, pathMatch={6}, manifestMatch={7}' -f $BrowserName, $ProfileName, $Id, $RawPath, $ResolvedPath, $StoredName, $PathMatches, $ManifestMatches)

            if ($PathMatches -or $ManifestMatches -or $StoredNameMatches) {
                $Results += [pscustomobject]@{
                    Browser = $BrowserName
                    Profile = $ProfileName
                    Id = $Id
                    Path = $ResolvedPath
                    Match = if ($PathMatches) { 'extension-folder-path' } elseif ($ManifestMatches) { 'local-manifest' } else { 'stored-name' }
                }
            }
        }
    }
    catch {
        Write-Log ('Preference parse failed: ' + $PreferenceFile + ' / ' + $_.Exception.Message)
    }

    return $Results
}

function Find-InstalledTripoExtensions {
    $ExpectedPath = Get-NormalizedPath $ExpectedExtensionRoot
    Write-Log ('Expected extension path: ' + $ExpectedPath)

    $Browsers = @(
        [pscustomobject]@{ Name = 'Chrome'; Root = (Join-Path $env:LOCALAPPDATA 'Google\Chrome\User Data') },
        [pscustomobject]@{ Name = 'Whale'; Root = (Join-Path $env:LOCALAPPDATA 'Naver\Naver Whale\User Data') }
    )

    $All = @()
    foreach ($Browser in $Browsers) {
        Write-Log ('Scanning browser root: ' + $Browser.Name + ' / ' + $Browser.Root)
        foreach ($ProfileName in (Get-BrowserProfiles $Browser.Root)) {
            $ProfileRoot = Join-Path $Browser.Root $ProfileName
            foreach ($FileName in @('Secure Preferences', 'Preferences')) {
                $PreferenceFile = Join-Path $ProfileRoot $FileName
                $All += @(Find-ExtensionInPreference $PreferenceFile $Browser.Name $ProfileName $Browser.Root $ExpectedPath)
            }
        }
    }

    return @($All | Sort-Object Browser, Profile, Id -Unique)
}

function Save-UpdaterExtensionPath {
    param([string]$ExtensionPath)

    $Normalized = Get-NormalizedPath $ExtensionPath
    if ([string]::IsNullOrWhiteSpace($Normalized)) {
        throw '업데이트 대상 확장 프로그램 폴더 경로를 확인하지 못했습니다.'
    }

    $ManifestPath = Join-Path $Normalized 'manifest.json'
    if (-not (Test-Path -LiteralPath $ManifestPath)) {
        throw "업데이트 대상 폴더에서 manifest.json을 찾지 못했습니다.`r`n$Normalized"
    }

    [ordered]@{
        extensionPath = $Normalized
        savedAt = (Get-Date).ToString('o')
        savedBy = 'native-host-easy-installer'
    } | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $UpdaterConfigPath -Encoding UTF8

    Write-Log ('Saved updater extension path: ' + $Normalized)
    return $Normalized
}

function Install-NativeHost {
    param(
        [string[]]$ExtensionIds,
        [string]$ExtensionPath
    )

    New-Item -ItemType Directory -Force -Path $InstallRoot, $NativeRoot | Out-Null
    $SavedExtensionPath = Save-UpdaterExtensionPath $ExtensionPath
    Copy-Item -LiteralPath (Join-Path $SourceRoot 'Tripo-Update-Helper.ps1') -Destination $InstallRoot -Force

    # Create an ASCII-named Windows shortcut. Explorer launches this shortcut
    # outside the short-lived Native Messaging host process.
    $ShortcutPath = Join-Path $InstallRoot 'Launch-Tripo-Updater.lnk'
    $PowerShellExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $UpdaterScriptPath = Join-Path $InstallRoot 'Tripo-Update-Helper.ps1'
    $Shell = New-Object -ComObject WScript.Shell
    $Shortcut = $Shell.CreateShortcut($ShortcutPath)
    $Shortcut.TargetPath = $PowerShellExe
    $Shortcut.Arguments = '-NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Normal -File "' + $UpdaterScriptPath + '"'
    $Shortcut.WorkingDirectory = $InstallRoot
    $Shortcut.WindowStyle = 1
    $Shortcut.Description = 'Tripo Update Helper'
    $Shortcut.Save()
    if (-not (Test-Path -LiteralPath $ShortcutPath)) {
        throw '업데이트 도우미 바로가기 생성에 실패했습니다.'
    }

    $HelperCmd = Join-Path $SourceRoot '2_RUN_UPDATE_HELPER.cmd'
    if (Test-Path -LiteralPath $HelperCmd) {
        Copy-Item -LiteralPath $HelperCmd -Destination $InstallRoot -Force
    }

    Copy-Item -LiteralPath $SourceCode -Destination $NativeRoot -Force

    $Compiler = Join-Path ([Runtime.InteropServices.RuntimeEnvironment]::GetRuntimeDirectory()) 'csc.exe'
    if (-not (Test-Path -LiteralPath $Compiler)) {
        throw '.NET Framework C# 컴파일러(csc.exe)를 찾지 못했습니다.'
    }

    $CompileArgs = @(
        '/nologo',
        '/target:exe',
        '/platform:anycpu',
        '/reference:System.Web.Extensions.dll',
        ('/out:"' + $HostExe + '"'),
        ('"' + $SourceCode + '"')
    )

    $Process = Start-Process -FilePath $Compiler -ArgumentList $CompileArgs -Wait -PassThru -NoNewWindow
    if ($Process.ExitCode -ne 0 -or -not (Test-Path -LiteralPath $HostExe)) {
        throw 'Native Host 실행 파일 생성에 실패했습니다.'
    }

    $Manifest = [ordered]@{
        name = $HostName
        description = 'Tripo Update Helper Native Messaging Host'
        path = $HostExe
        type = 'stdio'
        allowed_origins = @($ExtensionIds | ForEach-Object { 'chrome-extension://' + $_ + '/' })
    }
    $Manifest | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $HostManifest -Encoding UTF8

    $RegistryPaths = @(
        "HKCU:\Software\Google\Chrome\NativeMessagingHosts\$HostName",
        "HKCU:\Software\Naver\Naver Whale\NativeMessagingHosts\$HostName"
    )
    foreach ($RegistryPath in $RegistryPaths) {
        New-Item -Path $RegistryPath -Force | Out-Null
        Set-Item -Path $RegistryPath -Value $HostManifest
    }

    [ordered]@{
        installedAt = (Get-Date).ToString('o')
        hostName = $HostName
        extensionIds = $ExtensionIds
        extensionPath = $SavedExtensionPath
        updaterConfig = $UpdaterConfigPath
        hostManifest = $HostManifest
        registryPaths = $RegistryPaths
    } | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $InstallRoot 'native-host-install.json') -Encoding UTF8
}

try {
    Remove-Item -LiteralPath $LogPath -Force -ErrorAction SilentlyContinue
    Write-Log 'Auto installer started.'

    if (-not (Test-Path -LiteralPath (Join-Path $ExpectedExtensionRoot 'manifest.json'))) {
        throw "설치 파일 옆의 extension 폴더를 찾지 못했습니다.`r`nZIP 구조를 바꾸지 말고 전체 압축을 푼 뒤 다시 실행하세요."
    }

    $Answer = [System.Windows.Forms.MessageBox]::Show(
        "Tripo 업데이트 연결 도우미를 설치합니다.`r`n`r`n현재 ZIP의 extension 폴더로 등록된 Chrome/Whale 확장 프로그램을 자동으로 찾습니다.`r`n사용자가 ID를 입력할 필요가 없습니다.",
        'Tripo 간편 설치',
        'OKCancel',
        'Information'
    )
    if ($Answer -ne [System.Windows.Forms.DialogResult]::OK) { exit 0 }

    $Found = @(Find-InstalledTripoExtensions)
    $Ids = @($Found | ForEach-Object { $_.Id.ToLowerInvariant() } | Where-Object { $_ -match '^[a-p]{32}$' } | Select-Object -Unique)

    if ($Ids.Count -eq 0) {
        Show-Warn (
            "설치된 Tripo 확장 프로그램을 자동으로 찾지 못했습니다.`r`n`r`n" +
            "Whale 주소창에 whale://extensions 를 입력하세요.`r`n" +
            "기존 시험용 Tripo 확장을 삭제한 뒤, 이 설치판 안의 extension 폴더를 '압축해제된 확장 프로그램을 로드합니다'로 등록하세요.`r`n`r`n" +
            "등록 후 이 설치 파일을 다시 실행하면 ID를 자동으로 찾습니다.`r`n`r`n" +
            "진단 로그:`r`n$LogPath"
        )
        try { Start-Process 'notepad.exe' $LogPath } catch {}
        exit 2
    }

    $Detail = ($Found | ForEach-Object { '- ' + $_.Browser + ' / ' + $_.Profile + ' / ID: ' + $_.Id + ' / 감지: ' + $_.Match }) -join "`r`n"
    $Confirm = [System.Windows.Forms.MessageBox]::Show(
        "아래 확장 프로그램을 자동으로 찾았습니다.`r`n`r`n$Detail`r`n`r`nNative Messaging에 등록할까요?",
        '자동 감지 성공',
        'YesNo',
        'Question'
    )
    if ($Confirm -ne [System.Windows.Forms.DialogResult]::Yes) { exit 0 }

    $DetectedPaths = @($Found | ForEach-Object { $_.Path } | Where-Object { $_ -and (Test-TripoManifest $_) } | Select-Object -Unique)
    $ExtensionPathToSave = if ($DetectedPaths.Count -gt 0) { $DetectedPaths[0] } else { $ExpectedExtensionRoot }

    Install-NativeHost -ExtensionIds $Ids -ExtensionPath $ExtensionPathToSave
    Write-Log ('Installed IDs: ' + ($Ids -join ', '))
    Write-Log ('Updater target path: ' + $ExtensionPathToSave)

    Show-Info (
        "설치가 정상적으로 끝났습니다.`r`n`r`n" +
        "자동 등록된 확장 프로그램 ID:`r`n" + ($Ids -join "`r`n") +
        "`r`n`r`n업데이트 대상 폴더도 자동 저장했습니다:`r`n" + $ExtensionPathToSave +
        "`r`n`r`nWhale 또는 Chrome을 모두 닫았다가 다시 실행하세요."
    ) '설치 완료'
}
catch {
    Write-Log ('ERROR: ' + $_.Exception.ToString())
    Show-ErrorMessage ("설치 중 오류가 발생했습니다.`r`n`r`n" + $_.Exception.Message + "`r`n`r`n진단 로그:`r`n" + $LogPath)
    try { Start-Process 'notepad.exe' $LogPath } catch {}
    exit 1
}
